<?php
/*
 ===========================================================================================
 + Cerberus Content Management System.
 + ---
 + - Author : Gary Christopher Johnson
 + - E-Mail : TinkeSoftware@Protonmail.com
 + - Company: Tinke Software
 + - Notes  : View this file in a non-formatting text editor for correct indentation display
 + ---
 +
 +
 +
 +
 +
 +
 +
 +
 +
 +
 +
 + ---
 + - File Location: root->Cerberus->System>Configuration->Global_SQL_Server_Configuration.php
 + - File Version:  0.6 - Wednesday, March 1st of 2023.
 + ---
 + -------------------------------------------------------------------------------
 + --()()--()()()--()()()--()()()---()()()--()()()--()--()------()()()------------
 + -()-----()------()--()--()---()--()------()--()--()--()------()----------------
 + -()-----()------()--()--()---()--()------()--()--()--()------()----------------
 + -()-----()------()--()--()---()--()------()--()--()--()------()----------------
 + -()-----()()()--()()()--()()()---()()()--()()()--()--()------()----------------
 + -()-----()------()--()--()---()--()------()--()--()--()------()----------------
 + -()-----()------()--()--()---()--()------()--()--()--()------()------------/-\-
 + -()-----()------()--()--()---()--()------()--()--()--()------()------------|4|-  ~ Wynn ~
 + --()()--()()()--()--()--()()()---()()()--()--()--()()()--()()()------------\-/- Build: 0.8
 ===========================================================================================
*/

/*
 ================================================================
 +
 +
 + Global S.Q.L. Connection, Access and Security Variables
 +
 +
 ================================================================
*/

$_ACCESS_SYSTEM_ELECTRONIC_MAIL_ADDRESS			= "";
$_ACCESS_DATABASE_SERVER_HOSTNAME			= "";
$_ACCESS_DATABASE_SERVER_USERNAME			= "";
$_ACCESS_DATABASE_SERVER_PASSWORD			= "";
$_ACCESS_DATABASE_SERVER_DATABASE_NAME			= "";
$_ACCESS_DATABASE_SERVER_DATABASE_TABLE_PREFIX		= "";
$_ACCESS_URL_CLEARTEXT					= "";
$_ACCESS_URL_SECURE					= "";
?>